import React from "react";

function Home() {
  return <h1>Selamat datang di halaman Home</h1>;
}

export default Home;
