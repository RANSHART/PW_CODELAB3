import React from "react";

function contact() {
  return <div>Anda bisa menghubungi kami melalui...</div>;
}

export default contact;
