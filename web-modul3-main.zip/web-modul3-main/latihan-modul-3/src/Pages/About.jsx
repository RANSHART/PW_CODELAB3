import React from "react";

function About() {
  return <h1>Anda bisa menghubungi kami melalui...</h1>;
}

export default About;
