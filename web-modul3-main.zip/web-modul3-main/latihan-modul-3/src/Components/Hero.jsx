import React from "react";
import Navbar from "./Navbar";

function hero() {
  return (
    // <img src="Assets/hero.jpg"  class="logo_foot" />
    <h1>HEROOO</h1>
  );
}

export default hero;
