import React from "react";
import Navbar from "./Navbar";
function footer() {
  return <div>footer</div>;
}

export default footer;
